import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import model.*;
public class StudentView extends JFrame

{
    private StudentModel model = new StudentModel();
    private MyPanel panel = new MyPanel();
    public StudentView()
    {
        super("Student Data Entry");
        setup();
        build();
        setVisible(true);
    }
    public void setup()
    {
        setSize(600,300);
        setLocation(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    public void build()
    {
        add(panel);
    }
    public class MyPanel extends JPanel implements MyObserver
    {

        private JLabel idLabel = new JLabel("Id:");

        private JTextField idField = new JTextField(2);

        private JLabel nameLabel = new JLabel("Name:");

        private JTextField nameField = new JTextField(10);

        private JButton setButton = new JButton("Set");

        private JLabel detailsLabel = new JLabel("");

       

        public MyPanel()

        {

            setup();

            build();

            model.attach(this);

        }

       

        public void setup()

        {

            setButton.addActionListener(new setListener());

        }

       

        public void build()

        {

            add(idLabel);

            add(idField);

            add(nameLabel);

            add(nameField);

            add(setButton);

            add(detailsLabel);

        }

       

        public void update()

        {

            String details = model.toString();

            detailsLabel.setText(details);

        }

       

        private class setListener implements ActionListener

        {

            public void actionPerformed(ActionEvent e)

            {

                int id = Integer.parseInt(idField.getText());

                String name = nameField.getText();

                model.set(id, name);

            }

        }

    }

}