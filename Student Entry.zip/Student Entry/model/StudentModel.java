package model;
public class StudentModel extends Updater
{
    // instance variables - replace the example below with your own
    private int id;
    private String name;
    public StudentModel()
    {
    }
    public void set (int id, String name)
    {
        this.id = id;
        this.name = name;
        updateViews();
    }
    public String toString()
    {
        String str = "Student set : id " + id + " name " +name;
        return str;
    }    
}
