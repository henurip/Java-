package model;
import java.util.*;
public class Updater
{
    private LinkedList<MyObserver> views = new LinkedList<MyObserver>();
   
    /**
     * Constructor for objects of class Updater
     */
    public Updater()
    {
    }
    public void attach (MyObserver o)
    {
        views.add(o);
    }
    public void detach (MyObserver o)
    {
        views.remove(o);
    }
    public void updateViews()
    {
        for(MyObserver view:views)
            view.update();
    }       
}
