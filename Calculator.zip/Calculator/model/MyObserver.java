package model;
public interface MyObserver
{
    public void update();
}
