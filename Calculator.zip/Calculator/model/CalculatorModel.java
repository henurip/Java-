package model;
public class CalculatorModel extends Updater //step1 : all models inherit from Updater
{
    private double result;
    public CalculatorModel()
    {
    }
    public void add(double number1,double number2)
    {
        result = number1 + number2;
        updateViews(); //step2 all procedures in models call UpdateViews 
    }
    public void substract(double number1,double number2)
    {
        result = number1 - number2;
        updateViews(); //step2 all procedures in models call UpdateViews 
    }
    public void multiply(double number1,double number2)
    {
        result = number1 * number2;
        updateViews(); //step2 all procedures in models call UpdateViews 
    }
    public void divide(double number1,double number2)
    {
        result = number1 / number2;
        updateViews(); //step2 all procedures in models call UpdateViews 
    }
    public double getResult()
    {
        return result;
    }    
}
