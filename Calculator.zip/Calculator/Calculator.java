import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import model.*;
public class Calculator extends JFrame
{
    private CalculatorModel model = new CalculatorModel(); // declare model first, if not you will get java null error because panel attach to model
    private MyPanel panel = new MyPanel();
    public Calculator()
    {
        setTitle("Calculator");
        setup();
        build();
    }
    private void setup()
    {
        setSize(270,100);
        setLocation(200,200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
    private void build()
    {
        add(panel);
    }    
    public class MyPanel extends JPanel implements MyObserver //step 3 all panels inherit from MyObserver --> panel needs to override update()
    {   
        private JTextField txtResult = new JTextField(10);
        private JTextField txtNumber1 = new JTextField(5);
        private JTextField txtNumber2 = new JTextField(5);
        private JButton btnPlus = new JButton("+");
        private JButton btnMinus = new JButton("-");
        private JButton btnMultiply = new JButton("*");
        private JButton btnDivide = new JButton("/");
        private JButton btnClear = new JButton("Clear");
        public MyPanel()
        {
            model.attach(this); //step 4 all panels attach() to model(s) --> so panel now in the list of observer that receive update()
            setup();
            build();
        } 
        private void setup()
        {
            btnPlus.addActionListener(new AddListener());
            btnMinus.addActionListener(new SubstractListener());
            btnMultiply.addActionListener(new MultiplyListener());
            btnDivide.addActionListener(new DivideListener());
            btnClear.addActionListener(new ClearListener());
        }
        private void build()
        {
            add(txtNumber1);
            add(txtNumber2);
            add(txtResult);
            add(btnPlus);
            add(btnMinus);
            add(btnMultiply);
            add(btnDivide);
            add(btnClear);
        }
        public void update()
        {
            txtResult.setText("" + model.getResult());
        } 
        public void clear()
        {
            txtNumber1.setText("");
            txtNumber2.setText("");
            txtResult.setText("");
        }
        private class AddListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                double one = Double.parseDouble(txtNumber1.getText());
                double two = Double.parseDouble(txtNumber2.getText());
                model.add(one,two);
            }
        }  
        private class SubstractListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                double one = Double.parseDouble(txtNumber1.getText());
                double two = Double.parseDouble(txtNumber2.getText());
                model.substract(one,two);
            }
        } 
        private class MultiplyListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                double one = Double.parseDouble(txtNumber1.getText());
                double two = Double.parseDouble(txtNumber2.getText());
                model.multiply(one,two);
            }
        } 
        private class DivideListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                double one = Double.parseDouble(txtNumber1.getText());
                double two = Double.parseDouble(txtNumber2.getText());
                model.divide(one,two);
            }
        }
        private class ClearListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
              clear();
            }  
        }   
    }   
}
