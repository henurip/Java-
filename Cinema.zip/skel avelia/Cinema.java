import java.util.*;
/**
 * class Cinema 
 */
public class Cinema
{
    private final String NAME = "MyCinema";
    protected double balance = 100000.00;
    protected double profit = 0.0;
    protected double income = 0.0; 
    private Theatres theatres = new Theatres();
    private Movies movies = new Movies();
    private Sessions sessions = new Sessions() ; 
    public Cinema()
    {
        menu();
    }
    private void menu()
    {
        char action = readAction();
        switch (action)
        {
            case 'M': addMovie(); break;
            case 'T': addTheatre(); break;
            case 'S': addSession(); break;
            case 'L': sellTickets(); break;
            case 'H': hireTheatre(); break;
            case 'R': report(); break;
            case 'X': exit(); break;
            case '?': help(); break;
            default: error();
        }
    }
    private char readAction()
    {
        System.out.print("Please enter your choice (M, T, S, L, H, R, X, ?): ");
        return In.nextUpperChar();
    }
    private void addMovie()
    {
        movies.add(); 
        menu();
    }
    private void addTheatre()
    {
        theatres.add(); 
        menu();
    }
    private void addSession()
    {
        System.out.println("Add a Session"); 
        String name = In.readString("\tEnter Session Name: ");
        Movie mov = movies.find(In.readInt("\tEnter Movie id: "));
        String error = " is incorrect, session aborted"; 
        if(mov != null)
        {
            Theatre the = theatres.find(In.readInt("\tEnter Theatre id: "));
            if(the != null)
            {
                int time = In.readInt("\tEnter Session Time - 0 for 9am, 1 for 12noon, 2 for 3pm or 3 for 6pm:   ");
                sessions.add(mov,the,name,time); 
            }
            else 
            {
                System.out.println("\tTheatre id"+error); 
            }
        }
        else 
        {
            System.out.println("\tMovie id"+error);
        }
        menu();
    }
    private void sellTickets()
    {
        sessions.sellTickets();
        menu();
    }
    private void hireTheatre()
    { 
        System.out.println("Hire a Theatre");
        Theatre thea = theatres.find(In.readInt("\tEnter Theatre id: "));
        if (thea == null)
        {
            System.out.println("\tTheatre id is incorrect, hire aborted ");
        }
        else
        {
            int time = In.readInt("\tEnter Session Time - 0 for 9am, 1 for 12noon, 2 for 3pm or 3 for 6pm:   ");
            if(thea.vacant(time))
            {
                double amount = In.readDouble("\tHire amount: $");
                income += amount; 
                thea.book(time);
                System.out.println("Theatre hired");
            }
            else
            {
                System.out.println("\tTheatre not available for the selected time, hire aborted");
            }
        }
        menu();
    }  
    private double income()
    {
        return sessions.income() + income;
    }
    private double cost()
    {
        return sessions.cost();
    }
    private void profit()
    { 
        profit = income() - cost();
    }
    private double balance()
    { 
        return balance + profit;
    }
    private void report()
    {   
        movies.show();
        theatres.show();
        sessions.show();
        profit(); 
        show(); 
        menu();
    } 
    
    private void exit()
    {
        if (!confirm())
            menu();
        else
            System.out.println("Goodbye");
    }
    private boolean confirm()
    {
        System.out.print("Are you sure (y/n)?: ");
        return In.nextUpperChar() == 'Y';
    }
    private void help()
    {
        System.out.println("Welcome to TuneMe; enter");
        System.out.println("M for Add Movie");
        System.out.println("T for Add Theatre");
        System.out.println("S for Add Session");
        System.out.println("H for Hire Theatre");
        System.out.println("R for Cinema Report");
        System.out.println("X to exit");
        menu();
    }
    private void error()
    {
        System.out.println("No action found. Try again");
        menu();
    }
    private void show()
    {   
        System.out.println(toString()); 
    }                
    public String toString()
    {   String s = "Cinema:";
        s += " cost = $" + cost();
        s += " income = $" + income();
        s += " profit = $" + profit;  
        s+= " balance = $" + balance();
        return s;   
    }
    //example output in the word document doesn't add the value from hire
}