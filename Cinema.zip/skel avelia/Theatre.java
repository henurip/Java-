public class Theatre extends Entity
{
    private int gold; 
    private int regular;
    private boolean vacant[] = {true, true, true, true}; 

    public Theatre(int id, String name, int gold, int regular)
    {
        super(id, name);
        this.gold = gold;
        this.regular = regular; 
    }

    public int goldSeats()
    {
        return gold;
    }

    public int regularSeats()
    {
        return regular;
    }

    public boolean vacant(int time)
    {
        return vacant[time]; 
    }

    public void book(int time)
    {
        vacant[time] = false; 
    }
    
    public String toString()
    {
        return "Theatre: " +super.toString(); 
    }
}