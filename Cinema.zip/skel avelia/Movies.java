public class Movies extends Entities
{
    public Movies()
    {
        
    }
    
    public void add()
    {
        System.out.println("Setup a Movie");
        String name = In.readString("\tEnter Movie Name: ");
        double cost = In.readDouble("\tEnter Movie Cost: "); 
        super.add(new Movie(++id, name, cost)); 
    }
    
    public Movie find(int id)
    {
        return (Movie)super.find(id); 
    }
    
    public String toString()
    {
        return "Movies\n" + super.toString(); 
    }
}
