import java.util.*;

/**
 * class Entities - complete
 */
public class Entities
{
    protected LinkedList<Entity> entities = new LinkedList<Entity>();
    protected int id = 0;
    protected Entity find(int id)
    {   
        for(Entity entity: entities)
        {  
            if (entity.matches(id))
                return entity;  
        }
        return null;    
    }  
    protected void add(Entity entity)
    {
        entities.add(entity);
    }
    public int readInt(String message)
    {
        System.out.print("Please enter " + message + ":");
        return In.nextInt();
    }
    public double readDouble(String message)
    {
        System.out.print("Please enter " + message + ":");
        return In.nextDouble();
    }
    public int size()
    {
        return entities.size();
    }
    public void show()
    {
        System.out.println(toString());
    }
    public String toString()
    {
        String str = "";
        int last = entities.size()-1; 
        for(Entity entity : entities)
            if(entities.indexOf(entity)!= last)
            str += entity.toString() + "\n";
            else 
            str += entity.toString(); 
        return str;
    }
}
