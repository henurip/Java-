
/**
 * class Entity - complete
 */
public class Entity 
{
    protected int id;
    protected String name;

    public Entity(int id, String name)
    {
        this.id = id;
        this.name = name;
    }
    public String getName()
    {
        return name;
    }
    public int getId()
    {
        return id;
    }
    public boolean matches(int id)
    {
       return this.id == id;
    }
    public void show()
    {   
        System.out.println(toString()); 
    }  
    public String toString()
    {
        return id + " " + name;
    }
}
