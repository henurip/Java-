public class Theatres extends Entities
{
    public Theatres()
    {
        
    }
    
    public void add()
    {
        System.out.println("Add a Theatre");
        String name = In.readString("\tEnter Theatre name: ");
        int gold = In.readInt("\tEnter number of Gold Class Seats: ");
        int regular = In.readInt("\tEnter number of Regular Seats: ");
        super.add(new Theatre(++id, name, gold, regular));
    }
    
    public Theatre find(int id)
    {
        return (Theatre) super.find(id);
    }
    
    public String toString()
    {
        return "Theatres\n"+super.toString(); 
    }
}