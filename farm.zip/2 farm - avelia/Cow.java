public class Cow
{
    private final double GROW_FACTOR = 25.5;
    private final double BEEF_PRICE = 3.10;
    private final double CARTAGE = 9.88;
    private double buy;
    private double weight = 100.0;
    private double price = 0.0;

    public Cow(double buy)
    {
        this.buy = buy;
    }

    public void feed(int grain)
    {
        weight += GROW_FACTOR * grain;
    }

    public void sell()
    {
        price = BEEF_PRICE * weight;
    }
    
    public double cost()
    {
        return buy + CARTAGE;
    }
    
    public double getPrice()
    {
        return price;
    }
    
    public String toString()
    {
        return "Cost: " +cost()+ " Weight: " +weight + " Price: " +price;
    }
}