
/**
 * Write a description of class Grain here.
 */
public class Grain
{
    private int amount = 0;
    private final double PRICE = 37;
    /**
     * Constructor for objects of class Grain
     */
    public Grain(int amount)
    {
        this.amount = amount;
    }
    public double cost()
    {
        return PRICE * amount;
    }
    public int getAmount()
    {
        return amount;
    }
}
