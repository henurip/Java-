
public class Dog extends Animal
{
    private boolean tail;

    public Dog(String name, String color, boolean tail)
    {
        super(name,color);
  
    }

    public void show()
    {
        System.out.println(super.toString() + tail);
    }
    public static void main(String args[])
    {
        Dog billy = new Dog("Billy","Black",false);
        billy.show();
    }   
}
