import java.util.*;
import java.text.*;
/**
 * Write a description of class Farm here.
 */
public class Farm
{
    private Grain grain;
    private Cattle cattle;
    /**
     * Constructor for objects of class Farm
     */
    public Farm()
    {    
        setup();
        run();
        show();
    }
    private void setup()
    {
        grain = new Grain(readGrain());
        cattle = new Cattle(readCattle(), readPrice());
    }
    public int readGrain()
    {
        return readInteger("How much grain? ");
    }
    public int readCattle()
    {
        return readInteger("How many cattle? ");
    }
    private double readPrice()
    {
        System.out.print("Price per steer? ");
        return In.nextDouble();
    }
    private int readInteger(String question)
    {
        System.out.print(question);
        return In.nextInt(); 
    }
    private void run()
    {
       cattle.feed(grain.getAmount());
       cattle.sell();
    }
    private void show()
    {
        System.out.println(toString()); 
    }
    private String formatted(double amount)
    {   
        DecimalFormat formatter = new DecimalFormat("###,##0.00");
        return formatter.format(amount); 
    }
    public String toString()
    {
        String str = "Cost is $" +formatted(cost());
        str +="\nIncome is $" +formatted(income());
        str +="\nProfit is $" +formatted(income() - cost()); 
        return str; 
    }
    private double cost()
    {
        return grain.cost() + cattle.cost();
    }
    private double income()
    {
        return cattle.income();
    }
 
}
