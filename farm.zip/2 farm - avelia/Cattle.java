import java.util.*;
/**
 * Write a description of class Cattle here.
 */
public class Cattle
{
    private LinkedList<Cow>cows = new LinkedList<Cow>();
    private int number;

    /**
     * Constructor for objects of class Cattle
     */
    public Cattle(int number, double cost)
    {
        this.number = number;
        setCows(cost);
    }

    public void setCows(double cost)
    {
        for(int i=0; i<number; i++)
            cows.add(new Cow(cost));
    }

    public double cost()
    {
        double total = 0;
        for(Cow cow: cows)
            total += cow.cost();
        return total; 
    }

    public void feed(int grain) //int or double
    {
        for(Cow cow : cows)
            cow.feed(grain / number);
    }

    public void sell()
    {
        for(Cow cow : cows)
            cow.sell(); 
    }
    
    public double income()
    {
        double total = 0;
        for(Cow cow : cows)
            total+= cow.getPrice();
        return total;
    }
    
    public double price()
    {
       return 0.0;
    }

    public String toString()
    {
        return "Number: " + number + " Cows: " +cows.get(0).toString(); 
    }
}
