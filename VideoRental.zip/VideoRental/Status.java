
/**
 * Enumeration class Status - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Status
{
    FOR_RENT, RENTED, DAMAGED
}
