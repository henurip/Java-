
public class Customers extends Records
{
    public Customers()
    {
    }
    public void add()
    {
        String name = readName("Please enter customer name");
        Customer customer = new Customer(++id, name);
        super.add(customer);
    }
    public Customer find(int id)
    {
        return (Customer) super.find(id);
    }
}