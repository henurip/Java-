public class Video extends Record
{ 
    private final double PRICE = 5.0; 
    private int period;
    private Customer renter;
    private Status status;
    public Video(int id, String name, int period)
    {  
       super(id,name);
       this.period = period;
    }
    public void rent(Customer customer)
    {  //set video status to rented
        System.out.print("\tVideo rented: " + super.getName());
        status = Status.RENTED;
        renter = customer;
    }        
    public void videoReturn()
    { //set video status to not rented 
        System.out.println("Video id:");
        status = Status.FOR_RENT;
        renter = null;
    }  
    public double getPrice()
    {
        return PRICE;
    }
    public boolean isOut()
    {
        return status == Status.RENTED;
    }
    public void show()
    {  
        System.out.println(toString());   
    }
    public String toString()
    {  
        String str =  super.toString() + period + " days" ;   
        if(isOut())
            str += " rented to " + renter.getName();
        return str;
    }
        
   }
