import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SimpleWindow extends JFrame
{
    private MyPanel panel = new MyPanel();

    public SimpleWindow()
    {
        super("This is my first window");
        setup();
        build();
    }
    public void setup()
    {
        setSize(300,250);
        setLocation(200,200);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    public void build()
    {
        add(panel);
    }
    public class MyPanel extends JPanel
    {
        private JTextField text = new JTextField(25);
        private JButton btnShow = new JButton("Show");
        private JButton btnClear = new JButton("Clear");
        
        public MyPanel()
        {
            //add(text);
            //add(btnShow);
            //add(btnClear);
            btnShow.setActionCommand("Heni Rachmawati");
            btnShow.addActionListener(new Listener());
            btnClear.setActionCommand("");
            btnClear.addActionListener(new Listener());
            setLayout(new FlowLayout());
            //setLayout(new GridLayout(3,1));
            //setLayout(new BorderLayout()); 
            //add(text,BorderLayout.EAST); 
            //add(btnShow,BorderLayout.WEST);
            //add(btnClear,BorderLayout.SOUTH);
            Box box = Box.createVerticalBox();
            box.add(text);
            box.add(Box.createVerticalStrut(50));
            box.add(btnShow);
            box.add(Box.createVerticalStrut(50));
            box.add(btnClear);
            add(box);
        }
        public class Listener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                text.setText(e.getActionCommand());
            }
        }    
    }
}
