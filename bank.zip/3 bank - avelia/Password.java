
/**
 * Write a description of class Password here.
 */
public class Password
{
    private String word;
    /**
     * Constructor for objects of class Password
     */
    public Password(String word)
    {
        this.word = word;
    }

    public boolean matches(String word)
    {
        return this.word.equals(word);
    }
}
