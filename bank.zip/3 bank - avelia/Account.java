
/**
 * Write a description of class Account here
 */
public class Account
{
    private String id;
    private double balance;

    /**
     * Constructor for objects of class Account
     */
    public Account(String id, double balance)
    {
        this.id = id;
        this.balance = balance;
    }
    public boolean matches(String id)
    {
        return this.id.equals(id);
    }
    public boolean has(double amount)
    {
        return balance > amount;
    }
    public void withdraw(double amount)
    {
        balance -= amount; 
    }
    public void deposit(double amount)
    {
        balance += amount;
    }
    public String toString()
    {
        return "Account id: " + id + " Balance: " + balance;
    }
}
