import java.util.*;
/**
 * Write a description of class Bank here.
 */
public class Bank
{
    private final int MAXIMUM = 10;
    private LinkedList<Customer> customers = new LinkedList<Customer>();
    /**
     * Constructor for objects of class Bank
     */
    public Bank()
    {
        setup();
        login();
    }
    private void setup()
    {
        Customer customer = new Customer("123T", "test");
        customer.add(new Account("456", 1000.00));
        customers.add(customer);
    }
    private void login()
    {
        String id = readId();
        Customer customer = find(id);
        if(customer == null)
            System.out.println("No Matching customer");
        else 
            customer.login(); 
    }
    private String readId()
    {
        System.out.print("Please enter your customer id: ");
        return In.nextLine();
    }
    private Customer find(String id)
    {
        for (Customer customer : customers)
        {
            if(customer.matches(id))
                return customer;
        }
        return null;
    }
}
