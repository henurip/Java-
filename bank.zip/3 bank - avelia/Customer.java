import java.util.*;
/**
 * Write a description of class Customer here.
 */
public class Customer
{
    private final int MAXIMUM = 10;
    private final int PASSWORD_ATTEMPTS = 3;
    private String id;    
    private Password password;
    private LinkedList<Account> accounts = new LinkedList<Account>();
    /**
     * Constructor for objects of class Customer
     */
    public Customer(String id, String password)
    {
        this.id = id;
        this.password = new Password(password);
    }

    public void login()
    {
        for (int i = 0; i < PASSWORD_ATTEMPTS; i++)
        {
            String word = readWord();
            if (password.matches(word))
            {
                choose();
                break;
            }
        }             
    }

    public void add(Account account)
    {
        accounts.add(account);
    }

    private String readWord()
    {
        System.out.print("Please enter your password: ");
        return In.nextLine();
    }

    public boolean matches(String id)
    {
        return this.id.equals(id);
    }

    private void choose()
    {
        String id = readAccount();
        Account account = find(id);
        if (account == null)
            System.out.println("No account found");
        else 
            menu(account); 
    }

    private String readAccount()
    {
        System.out.print("Please enter your account id: ");
        return In.nextLine();
    }

    private Account find(String id)
    {
        for (Account account : accounts)
            if (account.matches(id))
                return account;
        return null;
    }

    private void menu(Account account)
    {
        char action = readAction();
        switch (action)
        {
            case 'D': deposit(account); break;
            case 'W': withdraw(account); break;
            case 'S': show(account); break;
            case 'X': exit(account); break;
            case '?': help(account); break;
            default: error(account); 
        }
    }

    private char readAction()
    {
        System.out.print("Please enter your choice (D, W, S, X, ?): ");
        return In.nextUpperChar();    
    }
    
    private void deposit(Account account)
    {
        account.deposit(readAmount());
        menu(account);        
    }

    private double readAmount()
    {
        System.out.println("Please enter amount: ");
        return In.nextDouble();
    }

    private void withdraw(Account account)
    {
        double amount = readAmount();
        if (account.has(amount))
            account.withdraw(amount);
        else 
            System.out.println("Not enough money");
        menu(account); 
    }

    private void show(Account account)
    {
        System.out.println(account.toString());
        menu(account);
    }

    private void exit(Account account)
    {
        if (!confirm())
            menu(account);
    }

    private boolean confirm()
    {
        System.out.println("Are you sure (y/n)?: ");
        return In.nextUpperChar() == 'Y';
    }

    private void help(Account account)
    {
        System.out.println("Welcome to XYZ banking; enter");
        System.out.println("D for deposits");
        System.out.println("W for withdrawals");
        System.out.println("S to show account balance");
        System.out.println("X to exit");
        menu(account);
    }

    private void error(Account account)
    {
        System.out.println("No action found. Try again");
        menu(account);
    }

}
