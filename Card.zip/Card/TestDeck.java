public class TestDeck
{
    public TestDeck()
    {
        Deck deck = new Deck();
        Hand hand = new Hand();
        hand.add(deck.draw());
        hand.add(deck.draw());
        System.out.println(hand.toString());
    }   
}    
