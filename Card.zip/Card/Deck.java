import java.util.*;

public class Deck
{
    private LinkedList<Card> cards = new LinkedList<Card>();
    public Deck()
    {
        for (Suit suit : Suit.values())
            for(Rank rank : Rank.values())
                cards.add(new Card(suit, rank));
    }
    public void display()
    {
        for (Card card : cards)
            System.out.println(card.toString());
    }
    public int random()
    {
        return (int) (Math.random() * cards.size());
    } 
    public Card draw()
    {
        return cards.get(random());
    }   
}
