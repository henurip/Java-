import java.util.*;
public class Hand
{
    private LinkedList<Card> cards = new LinkedList<Card>();
    public Hand()
    {
    }
    public void add(Card card)
    {
        cards.add(card);
    }
    public int size()
    {
        return cards.size();
    }
    public int value()
    {
        int total = 0;
        for (Card card : cards)
            total += card.getValue();
        return total;    
    }
    public String toString()
    {
        String result = "";
        for (Card card : cards)
            result += card.toString() +", ";
        result += " value is " + value();
        return result;
    }
}
